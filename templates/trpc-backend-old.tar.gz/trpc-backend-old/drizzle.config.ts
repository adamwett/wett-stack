import type { Config } from 'drizzle-kit';

export default {
  schema: './src/drizzle/schema.ts',
  dialect: 'sqlite',
  dbCredentials: { url: DATABASE_URL },
} satisfies Config;
