/**
 * @author adamwett
 * File where all the endpoints are combined into a single router.
 * Used by both the frontend and backend.
 */

import { postRouter } from './routers/post';
import { router } from './trpc';

export const backendRouter = router({
  posts: postRouter,
});

export type BackendRouter = typeof backendRouter;
