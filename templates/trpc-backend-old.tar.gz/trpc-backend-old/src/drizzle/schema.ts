// Barrel file used for importing all the schemas at once when creating drizzle instance

export * from './schemas/auth';
export * from './schemas/posts';
