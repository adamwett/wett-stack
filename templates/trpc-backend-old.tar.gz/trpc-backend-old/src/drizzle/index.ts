import { type DrizzleD1Database, drizzle } from 'drizzle-orm/d1';
import * as schema from './schema';

export type DatabaseInstance = DrizzleD1Database<typeof schema>;

// makes an instance of drizzle with the schema
export const createDb = (env: Env): DatabaseInstance => {
  return drizzle(env.DB, {
    schema,
  });
};
